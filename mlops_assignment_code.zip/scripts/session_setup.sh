#!/usr/bin/env bash
# Run at the start of EVERY lab session:   source scripts/session_setup.sh
# The lab VM changes between sessions; only /home/cloud/workspace persists.
PROJECT=/home/cloud/workspace/mlops_assignment
VENV="$HOME/.venvs/heartml"          # local disk: fast, recreated if missing
export PATH="/home/cloud/workspace/bin:$PATH"   # persistent kubectl location
cd "$PROJECT" || return 1
if [ ! -x "$VENV/bin/python" ]; then
  echo "[setup] creating venv at $VENV (first run in this VM, ~2-4 min)"
  python3 -m venv "$VENV"
  "$VENV/bin/pip" install -q --upgrade pip
  "$VENV/bin/pip" install -q -r requirements.txt
  "$VENV/bin/pip" install -q -e .
fi
source "$VENV/bin/activate"
echo "[setup] python: $(which python) | $(python --version)"
python -c "import heartml, sklearn, mlflow; print('[setup] heartml', heartml.__version__, '| sklearn', sklearn.__version__, '| mlflow', mlflow.__version__)"
